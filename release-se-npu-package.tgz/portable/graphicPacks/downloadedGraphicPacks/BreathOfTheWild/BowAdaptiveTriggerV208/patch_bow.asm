# Wii U BOTW v208 ONLY. See README.md and HOOKS.md.
# No R2 polling, periodic re-arm, arrow attack, or Cemu modifications.
[BotwBowAdaptiveTriggerV208]
moduleMatches = 0x6267BFD0
.origin = codecave
BowState:

.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0
.uint 0

BowTable:

.uint 0x00000000
.uint 0x00291B04
.uint 0x00322404
.uint 0x00301B04
.uint 0x00281B04
.uint 0x00000000
.uint 0x00322404
.uint 0x00000000
.uint 0x00000000
.uint 0x002E1B04
.uint 0x00000000
.uint 0x003D2404
.uint 0x00000000
.uint 0x00332404
.uint 0x00332404
.uint 0x00322404
.uint 0x002D1B04
.uint 0x00382404
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x004F3604
.uint 0x00000000
.uint 0x00000000
.uint 0x00382404
.uint 0x003C2404
.uint 0x003F2404
.uint 0x002E1B04
.uint 0x00472D04
.uint 0x00000000
.uint 0x00432D04
.uint 0x00553604
.uint 0x00000000
.uint 0x003E2404
.uint 0x00492D04
.uint 0x00000000
.uint 0x00281B04
.uint 0x00000000
.uint 0x00322404
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00000000
.uint 0x00553604
.uint 0x00412D04

BowEntry:
lis r3, BowState@ha
addi r3, r3, BowState@l
li r4, 0

stw r4, 0x0(r3)
stw r4, 0x4(r3)
stw r4, 0x8(r3)
stw r4, 0xC(r3)
stw r4, 0x10(r3)
stw r4, 0x14(r3)
stw r4, 0x18(r3)
stw r4, 0x1C(r3)
stw r4, 0x20(r3)
stw r4, 0x24(r3)
stw r4, 0x28(r3)
stw r4, 0x2C(r3)
stw r4, 0x30(r3)
stw r4, 0x34(r3)
stw r4, 0x38(r3)
stw r4, 0x3C(r3)
stw r4, 0x40(r3)
stw r4, 0x44(r3)
stw r4, 0x48(r3)
stw r4, 0x4C(r3)
stw r4, 0x50(r3)
stw r4, 0x54(r3)
stw r4, 0x58(r3)
stw r4, 0x5C(r3)
stw r4, 0x60(r3)
stw r4, 0x64(r3)
stw r4, 0x68(r3)
stw r4, 0x6C(r3)
stw r4, 0x70(r3)
stw r4, 0x74(r3)
stw r4, 0x78(r3)
stw r4, 0x7C(r3)

li r4, 1
stw r4, 0x08(r3)
blr

# Helpers run only while the private GP lock is held. No game/OS calls.
# Off clears observation, not the Bow-ID tension cache.
BowOff:
lwz r4, 0x00(r12)
cmpwi r4, 0
beq BowOffClear
lwz r4, 0x48(r12)
addi r4, r4, 1
stw r4, 0x48(r12)
BowOffClear:
li r4, 0
stw r4, 0x00(r12)
stw r4, 0x18(r12)
stw r4, 0x1C(r12)
stw r4, 0x2C(r12)
lwz r4, 0x70(r12)
stw r4, 0x74(r12)
blr

BowPublish:
lwz r4, 0x24(r12)
cmpwi r4, 0
beqlr
lwz r5, 0x04(r12)
addi r5, r5, 1
andi. r5, r5, 0xFFFF
stw r5, 0x04(r12)
slwi r5, r5, 16
or r4, r4, r5
stw r4, 0x00(r12)
lwz r4, 0x38(r12)
addi r4, r4, 1
stw r4, 0x38(r12)
blr

BowTick:
stwu r1, -0x60(r1)
stw r0, 0x08(r1)
stw r3, 0xC(r1)
stw r4, 0x10(r1)
stw r5, 0x14(r1)
stw r6, 0x18(r1)
stw r7, 0x1C(r1)
stw r8, 0x20(r1)
stw r9, 0x24(r1)
stw r10, 0x28(r1)
stw r11, 0x2C(r1)
stw r12, 0x30(r1)
mfcr r0
stw r0, 0x38(r1)
mflr r0
stw r0, 0x3C(r1)
mfctr r0
stw r0, 0x40(r1)
lis r12, BowState@ha
addi r12, r12, BowState@l
addi r11, r12, 0x7C
BowTickLock:
lwarx r10, 0, r11
cmpwi r10, 0
bne BowTickLock
li r10, 1
stwcx. r10, 0, r11
bne BowTickLock
isync
lwz r4, 0x34(r12)
addi r4, r4, 1
stw r4, 0x34(r12)
lwz r4, 0x08(r12)
cmpwi r4, 0
bne BowTickOff
mr r3, r31
lis r11, 0x1000
cmplw r3, r11
blt BowTickOff
lis r11, -0x2000
cmplw r3, r11
bge BowTickOff
andi. r11, r3, 3
bne BowTickOff

lbz r4, 0x54(r3)
cmpwi r4, 1
bne BowTickOff
lwz r4, 0x64(r3)
andi. r4, r4, 1
bne BowTickOff
lwz r4, 0xE8(r3)
lis r11, 0x1000
cmplw r4, r11
blt BowTickOff
lis r11, -0x2000
cmplw r4, r11
bge BowTickOff
andi. r11, r4, 3
bne BowTickOff

# Reject a different Player layout: vtable+314 must be the verified getter.
lwz r4, 0x314(r4)
lis r5, 0x02D8
addi r5, r5, -0x6650
cmplw r4, r5
bne BowTickOff
lwz r5, 0x50(r3)
lwz r4, 0x5C(r12)
cmplw r3, r4
bne BowTickPlayerIdentity
lwz r4, 0x68(r12)
cmplw r4, r5
beq BowTickOff
BowTickPlayerIdentity:
lwz r4, 0x10(r12)
cmplw r3, r4
bne BowTickNewPlayer
lwz r4, 0x14(r12)
cmplw r4, r5
beq BowTickHandle
BowTickNewPlayer:
bl BowOff
stw r3, 0x10(r12)
stw r5, 0x14(r12)
lwz r4, 0x0C(r12)
addi r4, r4, 1
stw r4, 0x0C(r12)
li r4, 0
stw r4, 0x54(r12)
stw r4, 0x58(r12)
BowTickHandle:
# Player+7CC is EquipMgr; bow slot 2 is a 16-byte ProcLink at +7EC.
lwz r6, 0x7EC(r3)
lwz r7, 0x7F0(r3)
cmpwi r7, -1
beq BowTickOff
lis r11, 0x1000
cmplw r6, r11
blt BowTickOff
lis r11, -0x2000
cmplw r6, r11
bge BowTickOff
andi. r11, r6, 3
bne BowTickOff

lwz r4, 0x3C(r6)
cmplw r4, r7
bne BowTickOff
lwz r8, 0x40(r6)
lis r11, 0x1000
cmplw r8, r11
blt BowTickOff
lis r11, -0x2000
cmplw r8, r11
bge BowTickOff
andi. r11, r8, 3
bne BowTickOff

lbz r4, 0x54(r8)
cmpwi r4, 1
bne BowTickOff
lwz r4, 0x64(r8)
andi. r4, r4, 1
bne BowTickOff
lwz r4, 0x50(r8)
cmplw r4, r7
bne BowTickOff
# Recheck the link generation after reading the resolved object.
lwz r4, 0x3C(r6)
cmplw r4, r7
bne BowTickOff
lwz r4, 0x7F0(r3)
cmplw r4, r7
bne BowTickOff
lwz r4, 0x54(r12)
cmplw r4, r8
bne BowTickIdentity
lwz r4, 0x58(r12)
cmplw r4, r7
beq BowTickOff
BowTickIdentity:
lwz r4, 0x18(r12)
cmplw r4, r8
bne BowTickNewBow
lwz r4, 0x1C(r12)
cmplw r4, r7
bne BowTickNewBow
# Stable instance: no name parsing or DB access. Consume releases once/tick.
lwz r4, 0x70(r12)
lwz r5, 0x74(r12)
cmplw r4, r5
beq BowTickDone
stw r4, 0x74(r12)
li r4, 3
stw r4, 0x50(r12)
bl BowPublish
b BowTickDone
BowTickNewBow:
lwz r6, 0x04(r8)
lis r11, 0x1000
cmplw r6, r11
blt BowTickOff
lis r11, -0x2000
addi r11, r11, -16
cmplw r6, r11
bge BowTickOff
lbz r4, 0(r6)
cmpwi r4, 87
bne BowTickOff
lbz r4, 1(r6)
cmpwi r4, 101
bne BowTickOff
lbz r4, 2(r6)
cmpwi r4, 97
bne BowTickOff
lbz r4, 3(r6)
cmpwi r4, 112
bne BowTickOff
lbz r4, 4(r6)
cmpwi r4, 111
bne BowTickOff
lbz r4, 5(r6)
cmpwi r4, 110
bne BowTickOff
lbz r4, 6(r6)
cmpwi r4, 95
bne BowTickOff
lbz r4, 7(r6)
cmpwi r4, 66
bne BowTickOff
lbz r4, 8(r6)
cmpwi r4, 111
bne BowTickOff
lbz r4, 9(r6)
cmpwi r4, 119
bne BowTickOff
lbz r4, 10(r6)
cmpwi r4, 95
bne BowTickOff
li r9, 0
lbz r4, 11(r6)
addi r4, r4, -48
cmplwi r4, 9
bgt BowTickOff
mulli r9, r9, 10
add r9, r9, r4
lbz r4, 12(r6)
addi r4, r4, -48
cmplwi r4, 9
bgt BowTickOff
mulli r9, r9, 10
add r9, r9, r4
lbz r4, 13(r6)
addi r4, r4, -48
cmplwi r4, 9
bgt BowTickOff
mulli r9, r9, 10
add r9, r9, r4
lbz r4, 14(r6)
cmpwi r4, 0
bne BowTickOff
cmplwi r9, 72
bgt BowTickOff
cmpwi r9, 0
beq BowTickOff
lwz r4, 0x20(r12)
cmplw r4, r9
bne BowTickDB
lwz r4, 0x44(r12)
addi r4, r4, 1
stw r4, 0x44(r12)
b BowTickCacheReady
BowTickDB:
lis r4, BowTable@ha
addi r4, r4, BowTable@l
slwi r5, r9, 2
lwzx r4, r4, r5
srwi r5, r4, 16
stw r5, 0x6C(r12)
andi. r4, r4, 0xFFFF
stw r4, 0x24(r12)
stw r9, 0x20(r12)
lwz r4, 0x40(r12)
addi r4, r4, 1
stw r4, 0x40(r12)
BowTickCacheReady:
stw r8, 0x18(r12)
stw r7, 0x1C(r12)
li r4, 0
stw r4, 0x2C(r12)
lwz r4, 0x70(r12)
stw r4, 0x74(r12)
lwz r4, 0x30(r12)
addi r4, r4, 1
stw r4, 0x30(r12)
li r4, 2
stw r4, 0x50(r12)
lwz r4, 0x24(r12)
cmpwi r4, 0
bne BowTickArm
li r4, 0
stw r4, 0x00(r12)
b BowTickDone
BowTickArm:
bl BowPublish
b BowTickDone
BowTickOff:
li r4, 1
stw r4, 0x50(r12)
bl BowOff
BowTickDone:
.uint 0x7C0004AC
li r10, 0
stw r10, 0x7C(r12)
lwz r0, 0x40(r1)
mtctr r0
lwz r0, 0x3C(r1)
mtlr r0
lwz r0, 0x38(r1)
mtcrf 255, r0
lwz r3, 0xC(r1)
lwz r4, 0x10(r1)
lwz r5, 0x14(r1)
lwz r6, 0x18(r1)
lwz r7, 0x1C(r1)
lwz r8, 0x20(r1)
lwz r9, 0x24(r1)
lwz r10, 0x28(r1)
lwz r11, 0x2C(r1)
lwz r12, 0x30(r1)
lwz r0, 0x08(r1)
addi r1, r1, 0x60
lwz r0, 0x14(r1)
b 0x02D67D2C

BowLoadBegin:
stwu r1, -0x60(r1)
stw r0, 0x08(r1)
stw r3, 0xC(r1)
stw r4, 0x10(r1)
stw r5, 0x14(r1)
stw r6, 0x18(r1)
stw r7, 0x1C(r1)
stw r8, 0x20(r1)
stw r9, 0x24(r1)
stw r10, 0x28(r1)
stw r11, 0x2C(r1)
stw r12, 0x30(r1)
mfcr r0
stw r0, 0x38(r1)
mflr r0
stw r0, 0x3C(r1)
mfctr r0
stw r0, 0x40(r1)
lis r12, BowState@ha
addi r12, r12, BowState@l
addi r11, r12, 0x7C
BowLoadBeginLock:
lwarx r10, 0, r11
cmpwi r10, 0
bne BowLoadBeginLock
li r10, 1
stwcx. r10, 0, r11
bne BowLoadBeginLock
isync
bl BowOff
li r4, 1
stw r4, 0x08(r12)
lwz r4, 0x0C(r12)
addi r4, r4, 1
stw r4, 0x0C(r12)
lwz r4, 0x4C(r12)
addi r4, r4, 1
stw r4, 0x4C(r12)
li r4, 0
stw r4, 0x10(r12)
stw r4, 0x14(r12)
stw r4, 0x54(r12)
stw r4, 0x58(r12)
stw r4, 0x5C(r12)
stw r4, 0x68(r12)
BowLoadBeginDone:
.uint 0x7C0004AC
li r10, 0
stw r10, 0x7C(r12)
lwz r0, 0x40(r1)
mtctr r0
lwz r0, 0x3C(r1)
mtlr r0
lwz r0, 0x38(r1)
mtcrf 255, r0
lwz r3, 0xC(r1)
lwz r4, 0x10(r1)
lwz r5, 0x14(r1)
lwz r6, 0x18(r1)
lwz r7, 0x1C(r1)
lwz r8, 0x20(r1)
lwz r9, 0x24(r1)
lwz r10, 0x28(r1)
lwz r11, 0x2C(r1)
lwz r12, 0x30(r1)
lwz r0, 0x08(r1)
addi r1, r1, 0x60
mflr r0
b 0x02EB451C

BowLoadEnd:
stwu r1, -0x60(r1)
stw r0, 0x08(r1)
stw r3, 0xC(r1)
stw r4, 0x10(r1)
stw r5, 0x14(r1)
stw r6, 0x18(r1)
stw r7, 0x1C(r1)
stw r8, 0x20(r1)
stw r9, 0x24(r1)
stw r10, 0x28(r1)
stw r11, 0x2C(r1)
stw r12, 0x30(r1)
mfcr r0
stw r0, 0x38(r1)
mflr r0
stw r0, 0x3C(r1)
mfctr r0
stw r0, 0x40(r1)
lis r12, BowState@ha
addi r12, r12, BowState@l
addi r11, r12, 0x7C
BowLoadEndLock:
lwarx r10, 0, r11
cmpwi r10, 0
bne BowLoadEndLock
li r10, 1
stwcx. r10, 0, r11
bne BowLoadEndLock
isync
li r4, 0
stw r4, 0x08(r12)
BowLoadEndDone:
.uint 0x7C0004AC
li r10, 0
stw r10, 0x7C(r12)
lwz r0, 0x40(r1)
mtctr r0
lwz r0, 0x3C(r1)
mtlr r0
lwz r0, 0x38(r1)
mtcrf 255, r0
lwz r3, 0xC(r1)
lwz r4, 0x10(r1)
lwz r5, 0x14(r1)
lwz r6, 0x18(r1)
lwz r7, 0x1C(r1)
lwz r8, 0x20(r1)
lwz r9, 0x24(r1)
lwz r10, 0x28(r1)
lwz r11, 0x2C(r1)
lwz r12, 0x30(r1)
lwz r0, 0x08(r1)
addi r1, r1, 0x60
blr

BowReleaseA:
stwu r1, -0x60(r1)
stw r0, 0x08(r1)
stw r3, 0xC(r1)
stw r4, 0x10(r1)
stw r5, 0x14(r1)
stw r6, 0x18(r1)
stw r7, 0x1C(r1)
stw r8, 0x20(r1)
stw r9, 0x24(r1)
stw r10, 0x28(r1)
stw r11, 0x2C(r1)
stw r12, 0x30(r1)
mfcr r0
stw r0, 0x38(r1)
mflr r0
stw r0, 0x3C(r1)
mfctr r0
stw r0, 0x40(r1)
lis r12, BowState@ha
addi r12, r12, BowState@l
addi r11, r12, 0x7C
BowReleaseALock:
lwarx r10, 0, r11
cmpwi r10, 0
bne BowReleaseALock
li r10, 1
stwcx. r10, 0, r11
bne BowReleaseALock
isync
lwz r3, 0(r29)
lwz r4, 0x18(r12)
cmpwi r4, 0
beq BowReleaseADone
cmplw r3, r4
bne BowReleaseAReject
lwz r4, 0x1C(r12)
lwz r5, 0x50(r3)
cmplw r4, r5
bne BowReleaseAReject
lwz r4, 0x08(r12)
cmpwi r4, 0
bne BowReleaseAReject
lwz r4, 0x70(r12)
addi r4, r4, 1
stw r4, 0x70(r12)
lwz r4, 0x3C(r12)
addi r4, r4, 1
stw r4, 0x3C(r12)
b BowReleaseADone
BowReleaseAReject:
lwz r4, 0x64(r12)
addi r4, r4, 1
stw r4, 0x64(r12)
BowReleaseADone:
.uint 0x7C0004AC
li r10, 0
stw r10, 0x7C(r12)
lwz r0, 0x40(r1)
mtctr r0
lwz r0, 0x3C(r1)
mtlr r0
lwz r0, 0x38(r1)
mtcrf 255, r0
lwz r3, 0xC(r1)
lwz r4, 0x10(r1)
lwz r5, 0x14(r1)
lwz r6, 0x18(r1)
lwz r7, 0x1C(r1)
lwz r8, 0x20(r1)
lwz r9, 0x24(r1)
lwz r10, 0x28(r1)
lwz r11, 0x2C(r1)
lwz r12, 0x30(r1)
lwz r0, 0x08(r1)
addi r1, r1, 0x60
lwz r29, 0x1C(r1)
b 0x02528270

BowReleaseB:
stwu r1, -0x60(r1)
stw r0, 0x08(r1)
stw r3, 0xC(r1)
stw r4, 0x10(r1)
stw r5, 0x14(r1)
stw r6, 0x18(r1)
stw r7, 0x1C(r1)
stw r8, 0x20(r1)
stw r9, 0x24(r1)
stw r10, 0x28(r1)
stw r11, 0x2C(r1)
stw r12, 0x30(r1)
mfcr r0
stw r0, 0x38(r1)
mflr r0
stw r0, 0x3C(r1)
mfctr r0
stw r0, 0x40(r1)
lis r12, BowState@ha
addi r12, r12, BowState@l
addi r11, r12, 0x7C
BowReleaseBLock:
lwarx r10, 0, r11
cmpwi r10, 0
bne BowReleaseBLock
li r10, 1
stwcx. r10, 0, r11
bne BowReleaseBLock
isync
lwz r3, 0(r29)
lwz r4, 0x18(r12)
cmpwi r4, 0
beq BowReleaseBDone
cmplw r3, r4
bne BowReleaseBReject
lwz r4, 0x1C(r12)
lwz r5, 0x50(r3)
cmplw r4, r5
bne BowReleaseBReject
lwz r4, 0x08(r12)
cmpwi r4, 0
bne BowReleaseBReject
lwz r4, 0x70(r12)
addi r4, r4, 1
stw r4, 0x70(r12)
lwz r4, 0x3C(r12)
addi r4, r4, 1
stw r4, 0x3C(r12)
b BowReleaseBDone
BowReleaseBReject:
lwz r4, 0x64(r12)
addi r4, r4, 1
stw r4, 0x64(r12)
BowReleaseBDone:
.uint 0x7C0004AC
li r10, 0
stw r10, 0x7C(r12)
lwz r0, 0x40(r1)
mtctr r0
lwz r0, 0x3C(r1)
mtlr r0
lwz r0, 0x38(r1)
mtcrf 255, r0
lwz r3, 0xC(r1)
lwz r4, 0x10(r1)
lwz r5, 0x14(r1)
lwz r6, 0x18(r1)
lwz r7, 0x1C(r1)
lwz r8, 0x20(r1)
lwz r9, 0x24(r1)
lwz r10, 0x28(r1)
lwz r11, 0x2C(r1)
lwz r12, 0x30(r1)
lwz r0, 0x08(r1)
addi r1, r1, 0x60
lwz r29, 0x1C(r1)
b 0x02528530

BowReleaseC:
stwu r1, -0x60(r1)
stw r0, 0x08(r1)
stw r3, 0xC(r1)
stw r4, 0x10(r1)
stw r5, 0x14(r1)
stw r6, 0x18(r1)
stw r7, 0x1C(r1)
stw r8, 0x20(r1)
stw r9, 0x24(r1)
stw r10, 0x28(r1)
stw r11, 0x2C(r1)
stw r12, 0x30(r1)
mfcr r0
stw r0, 0x38(r1)
mflr r0
stw r0, 0x3C(r1)
mfctr r0
stw r0, 0x40(r1)
lis r12, BowState@ha
addi r12, r12, BowState@l
addi r11, r12, 0x7C
BowReleaseCLock:
lwarx r10, 0, r11
cmpwi r10, 0
bne BowReleaseCLock
li r10, 1
stwcx. r10, 0, r11
bne BowReleaseCLock
isync
lwz r3, 0(r30)
lwz r4, 0x18(r12)
cmpwi r4, 0
beq BowReleaseCDone
cmplw r3, r4
bne BowReleaseCReject
lwz r4, 0x1C(r12)
lwz r5, 0x50(r3)
cmplw r4, r5
bne BowReleaseCReject
lwz r4, 0x08(r12)
cmpwi r4, 0
bne BowReleaseCReject
lwz r4, 0x70(r12)
addi r4, r4, 1
stw r4, 0x70(r12)
lwz r4, 0x3C(r12)
addi r4, r4, 1
stw r4, 0x3C(r12)
b BowReleaseCDone
BowReleaseCReject:
lwz r4, 0x64(r12)
addi r4, r4, 1
stw r4, 0x64(r12)
BowReleaseCDone:
.uint 0x7C0004AC
li r10, 0
stw r10, 0x7C(r12)
lwz r0, 0x40(r1)
mtctr r0
lwz r0, 0x3C(r1)
mtlr r0
lwz r0, 0x38(r1)
mtcrf 255, r0
lwz r3, 0xC(r1)
lwz r4, 0x10(r1)
lwz r5, 0x14(r1)
lwz r6, 0x18(r1)
lwz r7, 0x1C(r1)
lwz r8, 0x20(r1)
lwz r9, 0x24(r1)
lwz r10, 0x28(r1)
lwz r11, 0x2C(r1)
lwz r12, 0x30(r1)
lwz r0, 0x08(r1)
addi r1, r1, 0x60
lwz r0, 0x6C(r1)
b 0x02528688

BowLifeSync:
stwu r1, -0x60(r1)
stw r0, 0x08(r1)
stw r3, 0xC(r1)
stw r4, 0x10(r1)
stw r5, 0x14(r1)
stw r6, 0x18(r1)
stw r7, 0x1C(r1)
stw r8, 0x20(r1)
stw r9, 0x24(r1)
stw r10, 0x28(r1)
stw r11, 0x2C(r1)
stw r12, 0x30(r1)
mfcr r0
stw r0, 0x38(r1)
mflr r0
stw r0, 0x3C(r1)
mfctr r0
stw r0, 0x40(r1)
lis r12, BowState@ha
addi r12, r12, BowState@l
addi r11, r12, 0x7C
BowLifeSyncLock:
lwarx r10, 0, r11
cmpwi r10, 0
bne BowLifeSyncLock
li r10, 1
stwcx. r10, 0, r11
bne BowLifeSyncLock
isync
cmpwi r31, 1
bne BowLifeSyncDone
lwz r4, 0x18(r12)
cmplw r4, r30
bne BowLifeSyncDone
lwz r4, 0x1C(r12)
lwz r5, 0x50(r30)
cmplw r4, r5
bne BowLifeSyncDone
lwz r4, 0x10(r1)
stw r4, 0x28(r12)
li r6, 1
stw r6, 0x2C(r12)
lwz r6, 0x60(r12)
addi r6, r6, 1
stw r6, 0x60(r12)
cmpwi r4, 0
bgt BowLifeSyncDone
stw r30, 0x54(r12)
stw r5, 0x58(r12)
bl BowOff
BowLifeSyncDone:
.uint 0x7C0004AC
li r10, 0
stw r10, 0x7C(r12)
lwz r0, 0x40(r1)
mtctr r0
lwz r0, 0x3C(r1)
mtlr r0
lwz r0, 0x38(r1)
mtcrf 255, r0
lwz r3, 0xC(r1)
lwz r4, 0x10(r1)
lwz r5, 0x14(r1)
lwz r6, 0x18(r1)
lwz r7, 0x1C(r1)
lwz r8, 0x20(r1)
lwz r9, 0x24(r1)
lwz r10, 0x28(r1)
lwz r11, 0x2C(r1)
lwz r12, 0x30(r1)
lwz r0, 0x08(r1)
addi r1, r1, 0x60
lis r3, 0x1047
b 0x024A29C8

BowDelete:
stwu r1, -0x60(r1)
stw r0, 0x08(r1)
stw r3, 0xC(r1)
stw r4, 0x10(r1)
stw r5, 0x14(r1)
stw r6, 0x18(r1)
stw r7, 0x1C(r1)
stw r8, 0x20(r1)
stw r9, 0x24(r1)
stw r10, 0x28(r1)
stw r11, 0x2C(r1)
stw r12, 0x30(r1)
mfcr r0
stw r0, 0x38(r1)
mflr r0
stw r0, 0x3C(r1)
mfctr r0
stw r0, 0x40(r1)
lis r12, BowState@ha
addi r12, r12, BowState@l
addi r11, r12, 0x7C
BowDeleteLock:
lwarx r10, 0, r11
cmpwi r10, 0
bne BowDeleteLock
li r10, 1
stwcx. r10, 0, r11
bne BowDeleteLock
isync
lwz r3, 0x0C(r1)
lwz r4, 0x10(r12)
cmplw r3, r4
bne BowDeleteCheckBow
stw r3, 0x5C(r12)
lwz r4, 0x50(r3)
stw r4, 0x68(r12)
bl BowOff
li r4, 0
stw r4, 0x10(r12)
stw r4, 0x14(r12)
lwz r4, 0x0C(r12)
addi r4, r4, 1
stw r4, 0x0C(r12)
b BowDeleteDone
BowDeleteCheckBow:
lwz r4, 0x18(r12)
cmpwi r4, 0
beq BowDeleteDone
cmplw r3, r4
bne BowDeleteDone
stw r3, 0x54(r12)
lwz r4, 0x50(r3)
stw r4, 0x58(r12)
bl BowOff
BowDeleteDone:
.uint 0x7C0004AC
li r10, 0
stw r10, 0x7C(r12)
lwz r0, 0x40(r1)
mtctr r0
lwz r0, 0x3C(r1)
mtlr r0
lwz r0, 0x38(r1)
mtcrf 255, r0
lwz r3, 0xC(r1)
lwz r4, 0x10(r1)
lwz r5, 0x14(r1)
lwz r6, 0x18(r1)
lwz r7, 0x1C(r1)
lwz r8, 0x20(r1)
lwz r9, 0x24(r1)
lwz r10, 0x28(r1)
lwz r11, 0x2C(r1)
lwz r12, 0x30(r1)
lwz r0, 0x08(r1)
addi r1, r1, 0x60
mflr r0
b 0x0378A378

BowDetach:
stwu r1, -0x60(r1)
stw r0, 0x08(r1)
stw r3, 0xC(r1)
stw r4, 0x10(r1)
stw r5, 0x14(r1)
stw r6, 0x18(r1)
stw r7, 0x1C(r1)
stw r8, 0x20(r1)
stw r9, 0x24(r1)
stw r10, 0x28(r1)
stw r11, 0x2C(r1)
stw r12, 0x30(r1)
mfcr r0
stw r0, 0x38(r1)
mflr r0
stw r0, 0x3C(r1)
mfctr r0
stw r0, 0x40(r1)
lis r12, BowState@ha
addi r12, r12, BowState@l
addi r11, r12, 0x7C
BowDetachLock:
lwarx r10, 0, r11
cmpwi r10, 0
bne BowDetachLock
li r10, 1
stwcx. r10, 0, r11
bne BowDetachLock
isync
lwz r4, 0x10(r1)
cmpwi r4, 2
bne BowDetachDone
lwz r3, 0x0C(r1)
lwz r4, 0x10(r12)
cmplw r3, r4
bne BowDetachDone
bl BowOff
BowDetachDone:
.uint 0x7C0004AC
li r10, 0
stw r10, 0x7C(r12)
lwz r0, 0x40(r1)
mtctr r0
lwz r0, 0x3C(r1)
mtlr r0
lwz r0, 0x38(r1)
mtcrf 255, r0
lwz r3, 0xC(r1)
lwz r4, 0x10(r1)
lwz r5, 0x14(r1)
lwz r6, 0x18(r1)
lwz r7, 0x1C(r1)
lwz r8, 0x20(r1)
lwz r9, 0x24(r1)
lwz r10, 0x28(r1)
lwz r11, 0x2C(r1)
lwz r12, 0x30(r1)
lwz r0, 0x08(r1)
addi r1, r1, 0x60
mflr r0
b 0x02D6F0D0

.callback entry BowEntry
.adaptiveTriggerRaw right BowState

# Original 80010014: lwz r0, 0x14(r1)
0x02D67D28 = b BowTick

# Original 7C0802A6: mflr r0
0x02EB4518 = b BowLoadBegin

# Original 4E800020: blr
0x02EB4E80 = b BowLoadEnd

# Original 83A1001C: lwz r29, 0x1C(r1)
0x0252826C = b BowReleaseA

# Original 83A1001C: lwz r29, 0x1C(r1)
0x0252852C = b BowReleaseB

# Original 8001006C: lwz r0, 0x6C(r1)
0x02528684 = b BowReleaseC

# Original 3C601047: lis r3, 0x1047
0x024A29C4 = b BowLifeSync

# Original 7C0802A6: mflr r0
0x0378A374 = b BowDelete

# Original 7C0802A6: mflr r0
0x02D6F0CC = b BowDetach
